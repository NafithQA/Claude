---
description: Assess release readiness — regression scope, gates, go/no-go checklist
argument-hint: <release name/version or list of included stories/Jira keys>
---

Use the **qa-engineer** agent to assess release readiness for:

**$ARGUMENTS**

1. From the included changes, use `qa-requirement-review` (PR/blast-radius
   logic) + `analytical-thinking` to determine the **regression scope**:
   which existing areas and suites must run.
2. Use `testing-methodologies` to lay out the **quality gates** for this
   release (which suites at which pipeline stage, entry/exit criteria).
3. Produce a **go/no-go checklist**: automated regression status,
   exploratory pass on high-risk areas, specialist passes required
   (security/performance/accessibility/mobile as risk dictates),
   open Critical/High defects, and rollback/feature-flag readiness.
4. State a clear **recommendation** (Go / Go-with-conditions / No-go)
   with the reasons and residual risk.

Do not change any ticket states or post to Jira unless I confirm.
