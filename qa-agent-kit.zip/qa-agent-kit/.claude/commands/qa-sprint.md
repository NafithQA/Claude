---
description: Run the full /qa-story workflow across many stories, then a consolidated sprint QA summary
argument-hint: <list of Jira keys, or an epic/sprint key>
---

Use the **qa-engineer** agent to run the full QA workflow (same phases as
`/qa-story`) across every story in:

**$ARGUMENTS**

Process one story at a time and pause if you hit ambiguity that needs my
input.

After all stories, produce a **sprint QA summary**:
- Per-story readiness (Ready / Needs work) and test-case counts
- Stories blocked by untestable requirements (with the gaps)
- Consolidated regression scope for the sprint
- Specialist testing needed (security/performance/accessibility/mobile)
  and rough effort
- Top residual risks across the sprint

Do not post anything to Jira unless I explicitly confirm.
