---
description: Full QA workflow for one story (requirement review → risk → cases → data → automation)
argument-hint: <Jira key, or pasted story/acceptance criteria>
---

Use the **qa-engineer** agent to run the full QA workflow for:

**$ARGUMENTS**

If this looks like a Jira key and the Atlassian connector is available,
read the story and its acceptance criteria directly. If it's free text or
a URL, work from that. If details are missing, list what you need before
proceeding.

Execute these phases in order, applying the matching skill at each step
and showing the output of each phase before moving on:

1. **Requirement review** (`qa-requirement-review`) — verdict
   (Ready / Needs work) + numbered testability issues + rewritten weak
   acceptance criteria. If the story is not testable, STOP here and
   report the gaps.
2. **Risk decomposition** (`analytical-thinking`) — system decomposition
   and a ranked failure-hypothesis table (Impact × Likelihood).
3. **Scope selection** (`testing-methodologies`) — which test types and
   levels this change needs, and the regression blast radius.
4. **Test cases** (`test-case-generation`) — full traceable cases in the
   org template, tagged by suite and automation candidacy. Pull in the
   relevant specialist skills where the risk table points to them
   (`api-testing`, `security-testing`, `performance-testing`,
   `accessibility-testing`, `mobile-testing`).
5. **Test data** (`data-faker`) — the valid and hostile datasets these
   cases need (describe them; generate samples if a code environment is
   available).
6. **Automation plan** (`test-automation-standards`) — which cases to
   automate, at which level, and why.

End with a coverage summary: what's covered, what's not, residual risk,
and any open questions for the team. Do not post anything to Jira unless
I explicitly confirm.
