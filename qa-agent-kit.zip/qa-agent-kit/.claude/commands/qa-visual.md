---
description: Visual QA pass — cross-browser/device matrix + visual regression + Core Web Vitals
argument-hint: <page/route/component>
---

Use the **qa-engineer** agent to run a visual QA pass on:

**$ARGUMENTS**

Execute these phases in order, applying the matching skill at each step
and showing the output of each phase before moving on:

1. **Cross-browser/device matrix** — define the combination matrix for
   this target: browsers per your supported list, device classes
   (desktop/tablet/mobile — pull the tiered device list from
   `mobile-testing` where the target is mobile-relevant), and the key
   viewport breakpoints. Flag any known engine-specific risk areas worth
   closer attention for this particular target.
2. **Visual regression** (`visual-regression-testing`) — identify which
   states to snapshot (default, hover/focus, empty, error, loading,
   light/dark, RTL if supported) and which regions to mask or exclude as
   volatile. Specify the determinism setup needed (frozen data/time via
   `data-faker`, disabled animations, font/image load waits) and the
   baseline-review expectation. If a code environment and the target are
   available, scaffold the snapshot test; otherwise give the exact test
   outline.
3. **Frontend performance** (`frontend-performance`) — the Core Web
   Vitals to measure (LCP/INP/CLS) with the device+throttle profile to
   use, the per-page checklist items most relevant here (images, fonts,
   bundle, third-party scripts, layout-shift sources), and the CI budget
   to assert.

End with: the consolidated check matrix (combos × states × metrics), a
prioritized list of the likeliest failure points for THIS target, and
any open questions. Flag any real regressions found via `bug-triage`
severity. Don't update visual baselines or post to any tool without my
explicit confirmation.
