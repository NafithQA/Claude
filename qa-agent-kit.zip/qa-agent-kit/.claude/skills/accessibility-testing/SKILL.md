---
name: accessibility-testing
description: >
  RECONSTRUCTED FROM SUMMARY (see kit README) — original wording not
  recovered verbatim. Org-standard accessibility testing practices
  targeting WCAG AA. Use whenever a story touches UI, and whenever asked
  to check accessibility, a11y, keyboard navigation, or screen reader
  support. Trigger on mentions of WCAG, a11y, axe, screen reader, or
  keyboard navigation.
---

# Accessibility Testing

<!-- CUSTOMIZE: your conformance target and tooling -->
## Target & tools

- Conformance target: [e.g., WCAG 2.2 AA]
- Automated scanner: [e.g., axe-core, in CI on every PR touching UI]
- Screen readers used for manual passes: [e.g., NVDA + VoiceOver]

## Automated pass (every UI PR)

- [ ] axe (or equivalent) scan runs in CI and is clean, or violations
      are ticketed with a documented exception
- [ ] Color contrast meets the target ratio for text and UI components

## Keyboard-only pass (manual, every new UI flow)

- [ ] Every interactive element is reachable and operable via keyboard
      alone, in a logical tab order
- [ ] Focus is visible at every step and never trapped unintentionally
- [ ] Modals/menus close with Escape and return focus sensibly

## Screen reader pass (manual, every new UI flow)

- [ ] Headings, landmarks, and reading order make sense out of context
- [ ] Images have meaningful alt text (or are marked decorative)
- [ ] Form fields have programmatic labels and error messages are
      announced
- [ ] Dynamic content changes (toasts, live updates) are announced via
      appropriate ARIA live regions

## Definition of done additions

A UI story is not done until: axe scan clean, keyboard pass done, and —
for new flows — one screen reader pass recorded in the ticket.
