---
name: analytical-thinking
description: >
  Structured methods for decomposing a system or feature and
  anticipating where it will fail. Use at the START of any non-trivial
  testing engagement — before writing test cases for a complex feature,
  when planning testing for a new system/integration, when asked "what
  could go wrong here", "what should we test", or when doing risk
  analysis, root cause analysis, or exploratory testing charters.
---

# Analytical Thinking for QA

Use this before jumping to test cases. Output of this skill = a
decomposition map + a ranked failure hypothesis list that feeds
`test-case-generation`.

## Step 1 — Decompose the system (pick the lenses that fit)

- **Data flow**: trace each input from entry → validation → transform →
  storage → retrieval → display. Every arrow is a failure point.
- **Boundaries**: list every interface — UI↔API, service↔service,
  service↔DB, third parties, queues, caches, feature flags. Failures
  cluster at boundaries.
- **State model**: enumerate states and transitions of the core entities
  (order: draft→submitted→paid→shipped...). Ask: what happens on every
  *invalid* transition, and on events arriving in the wrong state?
- **Users & roles**: who touches this, with which permissions, on which
  devices, concurrently?
- **Time**: what is scheduled, cached, expiring, retried, or timezone-
  dependent?

## Step 2 — Anticipate failures systematically

For each component/boundary from step 1, run these prompts:

1. What if the input is missing, malformed, duplicated, or huge?
2. What if the dependency is slow, down, or returns garbage?
3. What if two of these happen at the same time? (race, double-submit,
   concurrent edit)
4. What if it's retried? (idempotency, duplicate side effects)
5. What if it partially fails midway? (consistency, orphaned data,
   money moved but order not created)
6. What if the user does things out of order, uses the back button,
   has two tabs open, or their session expires mid-flow?
7. What changed recently, and what shares code with it? (regression)
8. Where has this system hurt us before? (check bug history for the
   component — past defect clusters predict future ones)

## Step 3 — Rank and decide

Score each failure hypothesis: **Impact (1–3) × Likelihood (1–3)**.
- 6–9 → must have explicit test cases + consider automation
- 3–4 → test cases in extended suite or exploratory charter
- 1–2 → note as accepted risk, don't spend effort

## Output template

```
## System decomposition: <feature>
Components & boundaries: ...
Key states/transitions: ...
Data flows: ...

## Failure hypotheses (ranked)
| # | Hypothesis | Where | Impact | Likelihood | Score | Action |

## Open questions for the team
...
```

## Heuristics cheat sheet

- Follow the money and the data — irreversible effects deserve the most
  scrutiny.
- The bug is usually at a boundary, in error handling, or in state
  nobody drew on the whiteboard.
- "It can't happen" in a design discussion is a test case.
- If you can't explain how a component fails, you don't understand it
  yet — ask, don't skip.
