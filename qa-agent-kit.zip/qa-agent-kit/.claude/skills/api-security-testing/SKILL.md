---
name: api-security-testing
description: >
  NEWLY AUTHORED for this kit (no original source recovered) — written
  to match the scope described for this skill: concrete, defensively-
  framed test code for the OWASP API Security Top 10. Positioned as the
  implementation companion to `security-testing` (which defines scope
  and escalation rules). Use when writing automated tests that assert
  your own API correctly rejects known attack patterns. Only ever run
  against systems and environments you're authorized to test.
---

# API Security Testing — implementation

Companion to `security-testing`: that skill defines scope, checklist,
and escalation; this one gives runnable test shapes for the highest-
value OWASP API Top 10 checks. Every test here asserts the API
**correctly rejects or safely handles** a hostile input — none of it is
attack tooling, and none of it should ever be pointed at a system you
don't own or aren't authorized to test.

<!-- CUSTOMIZE: your API client/auth helpers -->
## Assumed helpers

- `api_client(role=...)` — returns an authenticated client for a given
  test role/tenant
- `create_resource(owner, ...)` — creates a resource owned by a given
  test user, for cross-ownership checks

## BOLA / IDOR (Broken Object Level Authorization)

The single highest-impact API check. For every endpoint that takes a
resource ID, confirm one user cannot act on another user's resource by
substituting the ID.

```python
def test_cannot_read_other_users_resource():
    owner = create_resource(owner="user_a")
    client_b = api_client(role="user_b")

    resp = client_b.get(f"/orders/{owner.id}")

    # Expect a consistent 404 (not 403) so existence isn't leaked either
    assert resp.status_code == 404

def test_cannot_modify_other_tenants_resource():
    owner = create_resource(owner="tenant_a")
    client_tenant_b = api_client(role="tenant_b")

    resp = client_tenant_b.patch(f"/invoices/{owner.id}", json={"status": "paid"})

    assert resp.status_code in (403, 404)
    assert get_resource(owner.id).status != "paid"  # side effect did not happen
```

## JWT `alg: none` / signature bypass

Confirm the API rejects tokens with a stripped or downgraded algorithm,
and tokens signed with the wrong key.

```python
def test_rejects_alg_none_token():
    forged = make_jwt(payload={"sub": "user_a", "role": "admin"}, alg="none")

    resp = api_client(token=forged).get("/admin/users")

    assert resp.status_code == 401

def test_rejects_token_signed_with_wrong_key():
    forged = make_jwt(payload={"sub": "user_a"}, key=WRONG_SIGNING_KEY)

    resp = api_client(token=forged).get("/me")

    assert resp.status_code == 401
```

## Mass assignment

Confirm the API ignores or rejects client-supplied fields it shouldn't
let clients set (role, balance, internal flags), even when the field
exists in the model.

```python
def test_mass_assignment_of_privileged_field_is_ignored():
    client = api_client(role="user")

    resp = client.post("/users", json={
        "email": "new@example.com",
        "role": "admin",          # not a field the client should control
        "account_balance": 999999,
    })

    assert resp.status_code in (200, 201)
    created = get_resource(resp.json()["id"])
    assert created.role == "user"           # default, not attacker-supplied
    assert created.account_balance == 0     # default, not attacker-supplied
```

## Rate limiting

Confirm sensitive/expensive endpoints (login, password reset, search)
actually enforce their documented rate limit.

```python
def test_login_endpoint_is_rate_limited():
    responses = [post_login(email="user@example.com", password="wrong")
                 for _ in range(RATE_LIMIT_THRESHOLD + 5)]

    assert any(r.status_code == 429 for r in responses)
    # and legitimate login still works after backing off / for another account
```

## Standing rules

- Run only against dedicated test/staging environments with synthetic
  data (`data-faker`) — never against production, and never against a
  system you don't own or aren't authorized to test.
- A failing test here (i.e., the attack pattern *succeeds*) is a
  security finding: escalate per `security-testing`'s reporting rules
  immediately, don't just mark the test as expected-fail and move on.
- Don't extend these patterns into anything that could cause real
  damage (data deletion, financial transactions, external service
  abuse) even in a test environment, without separate sign-off.
