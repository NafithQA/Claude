---
name: api-testing
description: >
  Org-standard approach for testing REST/GraphQL APIs. Use whenever
  designing or writing API tests, validating endpoints, testing
  contracts/schemas, integration testing between services, or reviewing
  API changes. Trigger on mentions of endpoint, REST, GraphQL, contract
  test, Postman, status codes, or request/response validation.
---

# API Testing

<!-- CUSTOMIZE: your tooling -->
## Stack

- Functional API tests: [e.g., pytest + httpx / REST Assured / Postman+Newman]
- Contract tests: [e.g., Pact / OpenAPI schema validation]
- Mocking/stubbing: [e.g., WireMock / respx]
- Environments & base URLs: [where configs live]

## Coverage model — test every endpoint on 5 axes

1. **Contract** — response matches the OpenAPI/GraphQL schema exactly:
   fields, types, nullability, enums, formats. Fail on undocumented
   fields appearing or documented ones missing.
2. **Status codes** — verify the full matrix, not just 200:
   - 200/201/204 for success variants (create vs update vs delete)
   - 400 malformed body / missing required field / wrong type
   - 401 no token, expired token; 403 valid token, wrong role/tenant
   - 404 nonexistent resource AND resource of another tenant (must not be 403 → info leak)
   - 409 duplicates/conflicts; 422 semantic validation
   - 429 rate limits where defined
3. **Data validation** — boundary values on every constrained field
   (min/max length, ranges, formats), empty strings vs null vs absent
   field (three different cases!), unicode/emoji, whitespace trimming,
   very large payloads.
4. **Behavior** — the change actually persisted (GET after POST/PUT),
   idempotency of PUT/DELETE and idempotency keys on POST where used,
   pagination (first/middle/last/empty page, invalid cursor), filtering
   and sorting combos, partial update semantics (PATCH null vs omit).
5. **Resilience** — timeouts, retries with backoff behavior, dependency
   down (use stubs), malformed JSON, wrong Content-Type, oversized
   request rejection.

## Standing rules

- Tests hit APIs through a typed client helper, never raw calls in test
  bodies (see `test-automation-standards`).
- Every test creates and cleans its own data; no shared fixtures that
  mutate.
- Assert on response body values, headers that matter (Content-Type,
  Cache-Control, pagination headers), and persistence — not just status
  code.
- Negative auth tests are mandatory for every new endpoint: no token,
  expired, wrong role, cross-tenant access.
- Log request + response on failure so triage never needs a rerun.

## Contract testing protocol

- Provider changes to a published API require: schema diff review,
  consumer contract verification green, versioning decision documented
  (backward compatible? new version? deprecation window?).
- Breaking-change checklist: removed/renamed field, type change,
  new required request field, enum value removal, semantics change of
  an existing field.

## GraphQL specifics (if applicable)

- Test each query/mutation with minimal and maximal selection sets.
- Verify error shape (`errors[]` with codes) and partial-data behavior.
- Depth/complexity limits and introspection policy per environment.
