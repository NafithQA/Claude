---
name: attention-to-detail
description: >
  RECONSTRUCTED FROM SUMMARY (see kit README) — original wording not
  recovered verbatim. Structured UI/UX inspection sweeps for catching
  the small things scripted test cases miss. Use during exploratory
  passes, visual QA, or before sign-off on any new UI, comparing
  implementation against design.
---

# Attention to Detail

Do one lens at a time — switching lenses mid-sweep is how things get
missed. Time-box each sweep and record every oddity immediately, even
if you're not sure it's a real bug yet.

## Sweep 1 — Visual vs. design

- Spacing, alignment, sizing match the design file at the breakpoints
  that matter
- Color, typography, and iconography match the design system (no
  one-off styles)
- States the design specifies (hover/focus/active/disabled/loading/
  empty/error) are all implemented, not just the default state

## Sweep 2 — Copy

- Spelling, grammar, and punctuation
- Terminology consistent with the rest of the product (not a synonym
  invented for this screen)
- Truncation/wrapping behaves at both very short and very long content
- Placeholder/lorem text is not accidentally shipped

## Sweep 3 — State matrix

- Every documented state actually renders correctly, including the ones
  that are hard to trigger (empty, error, permission-denied, offline)
- Transitions between states don't leave stale content on screen

## Sweep 4 — Interaction details

- Loading indicators appear for genuinely slow actions, not instant ones
- Disabled controls look and behave disabled (no phantom clickability)
- Double-submit is prevented on buttons that trigger side effects

## Sweep 5 — Environment matrix

- Behavior checked across the target browser/device/OS matrix, not just
  the primary dev environment
- Responsive behavior checked at real breakpoints, not just by resizing
  a desktop window

## Discipline rules

- Time-box each sweep; fatigue produces false negatives.
- Log an oddity the moment you see it — don't rely on remembering it
  after the sweep.
- If a design intent is unclear, ask rather than guessing what "close
  enough" means.
