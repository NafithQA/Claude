---
name: bug-triage
description: >
  Org-standard bug reporting format and triage process. Use whenever
  writing a bug report, reproducing a defect, assessing severity or
  priority, triaging incoming bugs, deciding duplicates, or summarizing
  defect trends. Trigger on mentions of bug, defect, issue, crash,
  regression, or "it's broken".
---

# Bug Triage & Reporting

## Bug report template (Jira description)

```
**Summary**: <component>: <symptom> when <action/condition>   ← also the ticket title

**Environment**: app version/build, OS/browser, environment (prod/staging), test account

**Steps to reproduce**:
1. ...
2. ...

**Actual result**: what happens (attach screenshot/video/log excerpt)
**Expected result**: what should happen + why (link requirement/AC)

**Reproducibility**: always / intermittent (x of y attempts)
**Workaround**: exists? describe / none
**First seen in**: version or date (regression? link last-good build)
**Evidence**: logs, HAR, stack trace, request/response, screen recording
```

## Severity vs priority (keep them separate)

Severity = technical impact:
- **S1 Blocker** — crash, data loss/corruption, security breach, core flow unusable, no workaround
- **S2 Major** — major function broken or wrong results; workaround painful
- **S3 Minor** — limited impact, reasonable workaround
- **S4 Trivial** — cosmetic, typo, minor UX polish

Priority = business urgency (P1 fix now → P4 backlog). A cosmetic bug on
the homepage may be S4/P1; an S2 in a deprecated module may be P4.

## Triage protocol for incoming bugs

1. **Reproduce first.** If not reproducible, request the missing info
   (exact build, account, data) before touching severity.
2. **Isolate the variable.** Different environment? Different data?
   Different user role? Narrow until the trigger is known.
3. **Check duplicates** — search Jira by component + symptom keywords
   before filing.
4. **Classify root-cause area**: product code / test code / environment /
   data / third-party. Only the first is a product bug.
5. **Assign severity by the matrix above**; propose priority with a
   one-line business rationale.
6. **Regression check**: if it worked before, identify the breaking
   change window — this changes priority conversations dramatically.

## Anti-patterns (reject these)

- "Doesn't work" with no steps
- Multiple defects in one ticket
- Severity inflated to get attention (use priority + rationale instead)
- Screenshots with no environment/build info
