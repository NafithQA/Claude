---
name: data-faker
description: >
  RECONSTRUCTED FROM SUMMARY (see kit README) — original SKILL.md prose
  not recovered verbatim; the generator script below is newly written
  to match the described behavior. Test/dummy data generation, including
  hostile/edge-case inputs. Use whenever test data is needed for a
  scenario, or when negative/boundary inputs need a concrete catalog.
  Never use real personal data.
---

# Test Data Generation

## Rule zero

Never use real customer/personal data in any non-production environment.
Always generate synthetic data instead.

## Script

`scripts/generate_data.py` generates realistic fake profiles using the
`faker` library, with a `--seed` flag for reproducibility (record the
seed in the ticket/test) and a `--nasty-ratio` flag to mix in hostile
rows for boundary/negative testing.

```
pip install faker
python scripts/generate_data.py --count 10 --locale en_US --format json --seed 42 --nasty-ratio 0.3
```

## "Nasty inputs" catalog (for negative/boundary cases)

- Empty string, whitespace-only, and maximum-length / over-length strings
- Unicode, emoji, right-to-left text, and mixed-script strings
- Names with apostrophes/hyphens (e.g., `O'Brien`, `Anne-Marie`)
- Malformed emails (`user@`, `@domain.com`, `user..name@domain.com`)
- Malformed or boundary dates (Feb 29 non-leap-year, year 0000, far future)
- Injection-looking strings (`' OR 1=1--`, `<script>alert(1)</script>`) —
  used purely as negative-test payloads to confirm the app rejects or
  safely encodes them, never to attempt exploitation. Anything that
  actually executes or leaks is an immediate `security-testing` escalation.
- Null vs empty vs absent field, tested as three distinct cases

## Usage guidance

- Prefer generating data through this script/catalog over hand-writing
  one-off fixtures, so hostile cases stay consistent across the team.
- Seed every generation you rely on for a reproducible test run.
