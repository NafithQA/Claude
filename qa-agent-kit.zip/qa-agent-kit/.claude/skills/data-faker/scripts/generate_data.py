#!/usr/bin/env python3
"""
Generate synthetic test-profile data for QA, with an optional mix of
hostile/edge-case ("nasty") rows for negative and boundary testing.

Never use real personal data — this script only ever produces synthetic
data via the `faker` library.

Usage:
    pip install faker
    python generate_data.py --count 10 --locale en_US --format json \
        --seed 42 --nasty-ratio 0.3
"""
import argparse
import csv
import io
import json
import random
import sys

NASTY_STRINGS = [
    "",
    " ",
    "A" * 500,
    "O'Brien",
    "Anne-Marie",
    "user@",
    "@domain.com",
    "user..name@domain.com",
    "'; DROP TABLE users; --",
    "<script>alert(1)</script>",
    "😀🔥💯 unicode test 中文 العربية",
]


def make_row(fake, nasty: bool) -> dict:
    if nasty:
        return {
            "first_name": random.choice(NASTY_STRINGS),
            "last_name": random.choice(NASTY_STRINGS),
            "email": random.choice(NASTY_STRINGS),
            "phone": random.choice(NASTY_STRINGS),
            "address": random.choice(NASTY_STRINGS),
            "city": random.choice(NASTY_STRINGS),
            "postal_code": random.choice(NASTY_STRINGS),
            "date_of_birth": random.choice(["0000-00-00", "2100-01-01", "2024-02-30"]),
            "_nasty": True,
        }
    return {
        "first_name": fake.first_name(),
        "last_name": fake.last_name(),
        "email": fake.email(),
        "phone": fake.phone_number(),
        "address": fake.street_address(),
        "city": fake.city(),
        "postal_code": fake.postcode(),
        "date_of_birth": fake.date_of_birth(minimum_age=18, maximum_age=90)
                             .isoformat(),
        "_nasty": False,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--count", type=int, default=10)
    p.add_argument("--locale", default="en_US")
    p.add_argument("--format", choices=["json", "csv"], default="json")
    p.add_argument("--seed", type=int, default=None,
                   help="Seed for reproducible output; record it in the ticket")
    p.add_argument("--nasty-ratio", type=float, default=0.0,
                   help="Fraction of rows using hostile/edge-case values (0..1)")
    args = p.parse_args()

    try:
        from faker import Faker
    except ImportError:
        sys.exit("Missing dependency: pip install faker")

    if args.seed is not None:
        random.seed(args.seed)
        Faker.seed(args.seed)
    fake = Faker(args.locale)

    rows = [make_row(fake, random.random() < args.nasty_ratio)
            for _ in range(args.count)]

    if args.format == "json":
        print(json.dumps(rows, ensure_ascii=False, indent=2))
    else:
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=rows[0].keys())
        w.writeheader()
        w.writerows(rows)
        print(buf.getvalue())


if __name__ == "__main__":
    main()
