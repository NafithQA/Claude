---
name: frontend-performance
description: >
  NEWLY AUTHORED for this kit (no original source recovered) — written
  to match the scope referenced by /qa-visual. Frontend performance
  testing against Core Web Vitals. Use whenever assessing page load
  performance, reviewing Core Web Vitals, or investigating perceived
  slowness in the UI.
---

# Frontend Performance Testing

<!-- CUSTOMIZE: your tooling & budgets -->
## Stack

- Measurement tool: [e.g., Lighthouse CI, WebPageTest, Chrome UX Report]
- Device + throttle profile: [e.g., mid-tier Android, Fast 3G/4G throttle]
- CI budget enforcement: [where budgets are defined and enforced]

## Core Web Vitals to measure

- **LCP** (Largest Contentful Paint) — perceived load speed; target
  ≤ 2.5s at the target device/throttle profile
- **INP** (Interaction to Next Paint) — responsiveness; target ≤ 200ms
- **CLS** (Cumulative Layout Shift) — visual stability; target ≤ 0.1

Always measure on the agreed device+throttle profile, not on a fast
dev machine over local network — that number lies about the real
experience.

## Per-page checklist

- [ ] Images sized/served appropriately (responsive images, modern
      formats, lazy-loaded below the fold)
- [ ] Fonts don't block render or cause visible layout shift on swap
- [ ] JS/CSS bundle size reviewed for this page; no unnecessary
      third-party scripts blocking the critical path
- [ ] Third-party scripts (analytics, chat widgets, ads) audited for
      their performance cost, deferred/async where possible
- [ ] Layout-shift sources identified: images/ads/embeds without
      reserved space, late-injected banners, web-font swap

## CI budget

Assert a budget per Core Web Vital (and optionally bundle size) in CI so
regressions are caught before merge, not discovered in production
monitoring. Treat a budget breach like a failing test, not a suggestion.

## Reporting

State the verdict against each Core Web Vital target, the biggest
contributor to any miss, and a prioritized fix recommendation — don't
just report the raw numbers.
