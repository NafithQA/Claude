---
name: jmeter-load
description: >
  NEWLY AUTHORED for this kit (no original source recovered) — written
  to match the scope described for this skill: Apache JMeter
  implementation how-to. Positioned as the tooling companion to
  `performance-testing` (which defines strategy, targets, and reporting).
  Use when actually building or running a JMeter test plan.
---

# JMeter Load Testing — implementation

Companion to `performance-testing`: that skill defines targets, test
types, and reporting; this one is the JMeter-specific how-to.

<!-- CUSTOMIZE: your environment specifics -->
## Environment

- JMeter version: [...]
- Load generator location: [where JMeter runs from — needs to be
  network-close to the target, not run from a laptop over VPN]
- Target environment & base URL: [...]

## Test plan structure

```
Test Plan
├── Thread Group (or Concurrency Thread Group for precise ramp control)
│   ├── HTTP Request Defaults   (base URL, common headers)
│   ├── HTTP Cookie Manager     (session handling)
│   ├── CSV Data Set Config     (parameterized test data — from data-faker)
│   ├── Samplers (HTTP Request) — one per transaction in the user journey
│   │   ├── Response Assertion  (status code / body content)
│   │   └── JSON Extractor      (correlate IDs/tokens into later requests)
│   └── Timers (Constant/Gaussian) — think time between steps
├── Listeners (during dev only — disable/aggregate for real runs)
└── Backend Listener → results backend (e.g., InfluxDB/Grafana), not
    just local listeners, for anything beyond a quick smoke check
```

## Building the script

1. **Record or hand-build** the user journey as a sequence of samplers
   matching the workload model from `performance-testing`.
2. **Correlate dynamic values** — session tokens, CSRF tokens, IDs
   returned by one request and needed by the next — via JSON/regex
   extractors. A script that replays a fixed captured token is not a
   valid load test.
3. **Parameterize test data** from a CSV Data Set Config sourced from
   `data-faker`, not hardcoded values, so every virtual user is
   realistic and doesn't collide on shared data.
4. **Add assertions**, not just a request — a script with no
   assertions can "pass" while the API silently returns errors.
5. **Set realistic timers** (think time) matching real user pacing;
   remove them only for a deliberate stress/spike test.

## Running at scale

- **Non-GUI mode for real runs**: `jmeter -n -t plan.jmx -l results.jtl -e -o report/`
  (GUI mode is for building/debugging only — never for real load)
- **Distributed testing** for load beyond one machine's capacity:
  configure remote JMeter servers and drive them from one controller;
  watch the controller's own resource usage so it isn't the bottleneck
- **Heap sizing**: increase JVM heap for high thread counts
  (`JVM_ARGS` / `HEAP` env var) — undersized heap produces misleading
  failures that look like the target failing

## Analyzing results

- Generate the HTML dashboard report (`-e -o report/` above) rather
  than reading the raw `.jtl` — percentiles and error breakdowns are
  pre-computed there
- Cross-reference JMeter's client-side timings with server-side/APM
  metrics from the same run window — a mismatch usually means network
  or the load generator itself is the bottleneck
- Feed results into the `performance-testing` reporting template

## Common mistakes

- Running from a single underpowered machine and blaming the target
- Leaving View Results Tree/Table listeners active during a real run
  (memory/CPU overhead skews results)
- No correlation — replaying stale tokens/IDs, silently getting 401s
  that don't fail the run because there's no assertion
- Confusing "requests per second the script sent" with "requests per
  second the server successfully handled"
