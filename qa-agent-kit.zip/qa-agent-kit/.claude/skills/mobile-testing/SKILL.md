---
name: mobile-testing
description: >
  RECONSTRUCTED FROM SUMMARY (see kit README) — original wording not
  recovered verbatim. Mobile-specific testing: device matrices, app
  lifecycle, connectivity, permissions, and release checks. Use whenever
  testing an iOS/Android/mobile-web feature, or planning a mobile
  release.
---

# Mobile Testing

<!-- CUSTOMIZE: your actual device/OS coverage -->
## Device matrix (tiered, driven by your analytics)

- Tier 1 (must pass): top devices/OS versions by real usage share
- Tier 2 (should pass): next tier by usage, plus oldest supported OS
  version and a low-end/low-memory device
- Tier 3 (spot-check): newest OS beta, largest and smallest screen sizes

## App lifecycle

- [ ] Backgrounding and returning mid-flow (mid-form, mid-upload,
      mid-payment) doesn't lose state or double-submit
- [ ] Incoming call/notification interruption during a critical flow
- [ ] Force-quit and relaunch recovers to a sane state
- [ ] Low memory conditions don't silently corrupt in-progress data

## Connectivity

- [ ] Offline entry into a flow shows a clear state, not a silent hang
- [ ] Flaky/slow network (throttled) — timeouts and retries behave
- [ ] Switching networks mid-request (Wi-Fi ↔ cellular) is handled

## Permissions, push, and deep links

- [ ] Permission prompts appear at the right moment with the right
      rationale; denial paths degrade gracefully rather than crashing
- [ ] Push notifications: delivery, tap-through routing, and behavior
      when the app is foregrounded/backgrounded/killed
- [ ] Deep links route correctly, including when the app isn't already
      running, and handle malformed/unknown links gracefully

## Upgrade & data migration

- [ ] Upgrading from the previous released version preserves user data
      and settings
- [ ] Upgrading across more than one version (skipping an intermediate
      release) still migrates data correctly

## Release checklist

- [ ] Device matrix above executed and signed off
- [ ] Store listing assets/metadata reviewed
- [ ] Crash-free rate and ANR rate checked against baseline before
      wider rollout
- [ ] Staged/phased rollout plan in place with a rollback trigger
