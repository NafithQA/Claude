---
name: performance-testing
description: >
  Org-standard process for performance, load, stress, and scalability
  testing. Use whenever planning or writing load tests, defining
  performance targets/SLOs, analyzing latency or throughput results,
  investigating slowness, or reviewing capacity for a release. Trigger
  on mentions of load test, k6, JMeter, Gatling, latency, p95, TPS,
  throughput, soak test, or "will it scale".
---

# Performance Testing

<!-- CUSTOMIZE: your tooling & environments -->
## Stack

- Load tool: [e.g., k6 / JMeter / Gatling / Locust]
- Monitoring during tests: [e.g., Grafana dashboards, APM link]
- Perf environment: [name, sizing vs prod ratio, data volume rules]
- Results archive: [Confluence space / repo folder]

## Golden rule: no test without targets

Never run a performance test without written pass/fail criteria first.
If the story has none, derive a proposal from production baselines and
get it agreed. Targets are stated as:

- Latency: p50 / p95 / p99 per transaction (ms) — never averages alone
- Throughput: requests or transactions per second at target load
- Error rate: max % under load (typically < 0.1–1%)
- Saturation: CPU/memory/connection-pool ceilings during the run

## Test types — pick deliberately

| Type | Question it answers | Shape |
|---|---|---|
| Baseline | What's normal for one user? | 1 VU, long enough for stable stats |
| Load | Does it meet SLOs at expected peak? | Ramp to expected peak, hold ≥ 15 min |
| Stress | Where does it break, and how? | Ramp beyond peak until failure |
| Spike | Does it survive sudden bursts? | Instant jump to N×, then back |
| Soak | Does it degrade over time? (leaks, bloat) | Moderate load, 2–8+ hours |
| Scalability | Do added resources add capacity? | Same load vs 1×/2×/4× instances |

## Workload modeling (the part people skip)

- Build scenarios from real traffic: top user journeys weighted by
  production frequency, not one endpoint hammered in isolation.
- Use realistic test data volumes — an empty database lies.
- Include think time and pacing; closed vs open workload model chosen
  consciously (open/arrival-rate for user-facing APIs).
- Warm up before measuring; exclude warm-up from results.

## Run protocol

1. Freeze the environment (no deploys, no other tests).
2. Record: build version, env sizing, data volume, tool + script version.
3. Run baseline first; abort if baseline already violates targets.
4. Execute; watch live dashboards — stop early on error-rate runaway.
5. Repeat the run at least twice; results must be reproducible within
   ~10% before you trust them.

## Reporting template

1. Verdict vs targets (pass/fail per metric, table)
2. Latency percentiles chart + throughput over time
3. Error breakdown by type/endpoint
4. Resource saturation observed (first bottleneck)
5. Comparison to previous release (regression?)
6. Recommendations + residual risk

## Anti-patterns

- Averages without percentiles
- Testing on laptop/shared env and extrapolating to prod
- One run, one number, no repeat
- Load generator itself saturated (monitor it too)
- Declaring victory at expected load without knowing the breaking point
