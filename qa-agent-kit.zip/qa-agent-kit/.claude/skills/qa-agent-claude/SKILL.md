---
name: qa-agent-claude
description: >
  NEWLY AUTHORED for this kit (no original source recovered) — written
  to match the scope described for this skill: an autonomous explore →
  generate → run → triage → heal → report loop, with strong guardrails.
  Use when explicitly asked to run an autonomous/unattended QA pass
  against a test environment, rather than a single planned workflow.
---

# Autonomous QA Loop

This skill is for autonomous, multi-step QA runs — not a replacement for
the planned commands (`/qa-story`, `/qa-plan`, etc.), which stay the
default for normal work. Use this only when explicitly asked to run
unattended, and only against a designated test/staging environment.

## The loop

1. **Explore** — crawl or navigate the target within its defined scope,
   building a map of pages/endpoints/flows. Use `analytical-thinking`
   to note the boundaries and states worth attention as you go.
2. **Generate** — for each area explored, generate test cases via
   `test-case-generation`, pulling in the relevant specialist skill
   (`api-testing`, `security-testing`/`api-security-testing`,
   `accessibility-testing`, `performance-testing`) where the area calls
   for it.
3. **Run** — execute the generated tests, following
   `test-automation-standards` for how the automation itself is written.
4. **Triage** — for every failure, apply `bug-triage` to classify root
   cause before doing anything else with it.
5. **Heal** — for failures classified as **test-code** issues (stale
   selector, timing, test data collision), fix the test and re-run.
   For failures classified as **product** issues, do NOT change the
   test to make it pass — that's the one failure mode this loop must
   never produce.
6. **Report** — end every run with: what was explored, what was tested,
   what passed/failed/was healed, and every real (product) defect found,
   filed via `bug-triage`'s template.

## Guardrails (non-negotiable)

- **Environment scope.** Only run against an explicitly designated
  test/staging environment. Never against production, and never against
  a system outside what was explicitly authorized for this run.
- **No destructive or financial actions** outside that designated test
  environment — no real payments, no irreversible deletes, no emails/
  notifications to real users — under any circumstance, including "just
  to see what happens."
- **No CAPTCHA or bot-detection bypass**, ever, regardless of the
  reason given.
- **Escalate real bugs, never weaken tests to reach green.** If a
  generated test correctly caught a real defect, the fix is a filed bug
  report — not a loosened assertion, a skipped test, or a "known issue"
  label applied without a ticket.
- **Pause on ambiguity** that changes scope or risk (e.g., the
  exploration surfaces something outside the intended target, or a
  failure looks like it could be a security issue) rather than
  proceeding autonomously — hand security-flavored findings to
  `security-testing`'s escalation path instead of continuing to probe.
- **Report everything the loop did**, including healed tests and areas
  it chose not to test and why — an autonomous run that "just shows
  green" without an audit trail isn't trustworthy.
