---
name: qa-requirement-review
description: >
  QA review checklists for requirements and pull requests. Use whenever
  reviewing a user story, acceptance criteria, spec, or design for
  testability — or reviewing a pull request from a quality/testing
  perspective. Trigger on "review this story", "are these ACs good",
  "shift-left", refinement/grooming prep, or "QA review of this PR".
---

# QA Review: Requirements & Pull Requests

## Requirement / story review (shift-left)

Assess each story against INVEST + testability. Output: a verdict
(Ready / Needs work), a numbered list of issues, and suggested rewrites
for weak acceptance criteria.

Checklist:
- [ ] Acceptance criteria are verifiable — each one can become at least
      one concrete test with a definite pass/fail
- [ ] No ambiguity words without definition: "fast", "user-friendly",
      "properly", "etc.", "as appropriate"
- [ ] Negative and error behavior specified (not just the happy path)
- [ ] Boundary values and limits stated (max lengths, ranges, quotas)
- [ ] Roles/permissions behavior defined
- [ ] Data requirements identified (migrations, backfills, PII handling)
- [ ] Non-functional needs stated or explicitly waived (performance
      targets, accessibility level, security constraints)
- [ ] Observability: how will we know it works in production? (logs,
      metrics, alerts)
- [ ] Dependencies and feature-flag/rollout plan noted

Rewrite weak ACs into Given/When/Then, e.g.:
> Weak: "Search should be fast."
> Better: "Given the catalog has ≤ 1M items, when a user searches by
> keyword, then first results render within 800 ms at p95."

## Pull request review (QA lens)

Focus on quality risk, not style (linters do style):

1. **Test coverage delta** — does the PR add/change tests matching the
   behavior change? New logic without tests = request changes.
2. **Edge cases in the diff** — nulls, empty collections, error paths,
   timeouts/retries, concurrency on shared state.
3. **Contract impact** — API/schema changes: versioned? backward
   compatible? consumer tests updated?
4. **Regression blast radius** — what existing features share this code
   path? Name the regression suites to run.
5. **Testability** — can this change be tested in isolation? Suggest
   seams/test IDs/flags if not.
6. **Migration & rollback** — data migrations reversible? feature flag
   guarding risky paths?

Output format: blocking issues, non-blocking suggestions, regression
scope recommendation, and any missing tests listed explicitly.
