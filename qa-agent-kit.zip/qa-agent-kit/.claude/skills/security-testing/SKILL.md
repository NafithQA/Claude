---
name: security-testing
description: >
  Org-standard security testing practices for QA — what to verify, when
  to escalate to the security team, and how to report findings safely.
  Use whenever a story touches authentication, authorization, sessions,
  payments, file uploads, user input, PII, or secrets, and whenever
  asked to do a security review of a feature or PR. Trigger on mentions
  of OWASP, auth, permissions, injection, XSS, tokens, or "is this secure".
---

# Security Testing (QA scope)

## Scope boundary

QA security testing verifies that defined security controls work. It
complements — never replaces — security-team activities (pen tests,
threat modeling, SAST/DAST program). **Escalate to the security team**
for: suspected exploitable vulnerabilities, anything touching crypto
design, and all findings rated High/Critical. Only test systems and
environments you're authorized to test.

<!-- CUSTOMIZE -->
## Org setup

- Security team contact / escalation channel: [...]
- Approved scanners in CI: [e.g., dependency audit, SAST tool, ZAP baseline]
- Finding tracker & confidentiality rules: [where security bugs go — usually a restricted Jira project, never public boards]

## Core checklist per feature

**Authentication & session**
- [ ] Endpoints reject missing/expired/malformed tokens (401)
- [ ] Logout/timeout actually invalidates the session server-side
- [ ] Password/reset flows: rate-limited, generic error messages (no
      user-enumeration via "email not found"), reset tokens single-use
      and expiring
- [ ] Sensitive cookies: HttpOnly, Secure, SameSite set

**Authorization (the #1 source of escaped defects)**
- [ ] Every object access tested cross-user and cross-tenant: user A
      must not read/update/delete user B's resource by swapping IDs
      (IDOR check) — expect 404/403 consistently
- [ ] Role matrix verified: each role tested against each protected
      action, including "role removed mid-session"
- [ ] Privilege checks enforced server-side, not only hidden in UI

**Input handling**
- [ ] All user input fields tested with hostile-looking data: quotes,
      angle brackets, script tags, extremely long strings, null bytes,
      unicode — verify output is encoded/escaped and errors are clean
      (this is negative testing, not exploitation: pass = nothing
      executes or leaks)
- [ ] File uploads: type/extension/size enforced server-side, files
      served with safe content types, no path traversal via filename
- [ ] IDs and parameters from the client are validated server-side

**Data exposure**
- [ ] API responses contain no over-fetching (fields the UI doesn't
      need: password hashes, internal flags, other users' data)
- [ ] PII masked in logs; secrets never in URLs, logs, or error messages
- [ ] Verbose stack traces disabled outside dev
- [ ] TLS enforced; no mixed content

**Platform hygiene**
- [ ] Dependency audit clean or exceptions ticketed (run in CI)
- [ ] Security headers present per org baseline (CSP, X-Content-Type-
      Options, frame options)
- [ ] Rate limiting verified on auth and expensive endpoints

## Reporting findings

- File in the restricted security tracker, not the public backlog.
- Include: affected endpoint/build, minimal reproduction, observed vs
  expected control behavior, and impact in plain language.
- Findings are confidential — do not discuss specifics outside the
  restricted tracker or the escalation channel above.
