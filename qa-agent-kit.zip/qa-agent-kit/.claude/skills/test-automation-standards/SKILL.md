---
name: test-automation-standards
description: >
  Org-wide standards for writing test automation code. Use whenever
  writing, reviewing, refactoring, or debugging automated tests — unit,
  API, or UI/E2E — or setting up test frameworks, fixtures, CI test
  stages, or flaky-test fixes. Trigger on mentions of Playwright,
  Selenium, Cypress, pytest, Jest, JUnit, or "automate this test".
---

# Test Automation Standards

<!-- CUSTOMIZE: set your actual stack here; the agent reads this first -->
## Approved stack

- UI/E2E: [e.g., Playwright + TypeScript]
- API: [e.g., pytest + requests / REST Assured]
- Unit: whatever the product codebase uses
- CI: [e.g., GitHub Actions / Jenkins — test stage names]

## Non-negotiable rules

1. **Independent tests.** Each test creates its own data and can run
   alone and in parallel. No dependence on execution order.
2. **No sleeps.** Use explicit waits/assertion polling. `sleep(5)` is an
   automatic review rejection.
3. **One behavior per test.** Test name states the behavior:
   `test_<unit>_<scenario>_<expected>` or `should <expected> when <scenario>`.
4. **Stable selectors.** UI tests use dedicated test IDs
   (`data-testid`), never brittle XPath/CSS chains or display text that
   changes with copy edits.
5. **Assert outcomes, not implementation.** Verify user-visible or
   API-contract results; avoid asserting on internal call counts unless
   testing the contract itself.
6. **Page Object / client abstraction.** No raw locators or raw HTTP
   calls inside test bodies. UI: page objects. API: typed client helpers.
7. **Deterministic data.** Seeded factories/fixtures; no reliance on
   pre-existing shared environment data. Clean up what you create.
8. **Failure diagnostics.** On failure capture: screenshot/trace (UI),
   request+response (API), and a meaningful assertion message.
9. **Pyramid discipline.** Prefer the lowest level that can catch the
   bug: unit > API > UI. Justify every new E2E test.

## Flaky test protocol

1. Reproduce locally with retries disabled.
2. Classify: race condition / test data collision / environment / real
   intermittent product bug.
3. Fix or quarantine with a ticket — never delete, never blanket-retry.

## Review checklist for automation PRs

- [ ] Runs green locally and in CI, in parallel mode
- [ ] Follows naming convention and folder layout
- [ ] No sleeps, no order dependence, no shared mutable data
- [ ] Selectors/test IDs stable; abstractions used
- [ ] Failure output is diagnosable without rerunning
- [ ] Added to the correct suite tag (smoke/regression)
