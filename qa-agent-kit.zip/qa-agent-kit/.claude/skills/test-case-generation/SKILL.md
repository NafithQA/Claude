---
name: test-case-generation
description: >
  Test case and test plan templates, design techniques, and coverage
  checklist. Use whenever writing test cases, designing a test plan for
  a feature/epic/release, or deciding what to test for a given story.
---

# Test Case & Test Plan Generation

## Process

1. Read the requirement/story and its acceptance criteria in full.
2. List testable conditions. Flag anything ambiguous or untestable as an
   open question — do not silently interpret.
3. Choose design techniques per condition (BVA, equivalence partitioning,
   decision table, state transition, pairwise).
4. Write test cases using the template below.
5. Classify each case: Smoke / Regression / Extended. Tag automation
   candidates.
6. Summarize coverage: what is covered, what is not, residual risk.

## Test case template

| Field | Rule |
|---|---|
| ID | `TC-<PROJECT>-<number>` (e.g., TC-PAY-042) |
| Title | Action + condition + expected outcome, ≤ 120 chars |
| Requirement link | Jira key or requirement ID — mandatory |
| Priority | P1 (critical path) / P2 (major) / P3 (minor) |
| Type | Functional / API / UI / Security / Performance / Accessibility |
| Preconditions | Exact system state and test data needed |
| Steps | Numbered, one action per step |
| Expected result | Verifiable per step or at the end — exact values, not "works correctly" |
| Suite | Smoke / Regression / Extended |
| Automation | Candidate: yes/no + reason |

## Coverage checklist (apply to every story)

- Happy path(s)
- Negative inputs (invalid, empty, malformed, wrong type)
- Boundary values (min, max, min−1, max+1, zero, empty set)
- State/permission variations (roles, logged out, expired session)
- Concurrency/idempotency where writes occur
- Error handling and user-facing messages
- Backward compatibility / migration impact where applicable
- Non-functional hooks: note if performance, security, or accessibility
  testing is warranted, even if out of scope for this pass

## Test plan template (for features/releases)

1. **Scope** — in scope, out of scope, assumptions
2. **Risk assessment** — top risks ranked by impact × likelihood; test
   effort allocated accordingly
3. **Approach** — levels (unit/API/UI/E2E), techniques, environments
4. **Entry / exit criteria**
5. **Test data & environment needs**
6. **Schedule & responsibilities**
7. **Deliverables & reporting cadence**

<!-- CUSTOMIZE: replace with your org's tooling -->
## Where artifacts live

- Test cases: [e.g., Xray / Zephyr / TestRail / Confluence page per epic]
- Test plans: [e.g., Confluence space "QA", template page link]
- Naming and labels: [your conventions]
