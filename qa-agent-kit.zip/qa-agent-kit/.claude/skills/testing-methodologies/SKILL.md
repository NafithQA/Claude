---
name: testing-methodologies
description: >
  Reference on software testing methodologies: the testing lifecycle
  (STLC), how QA operates in Agile/Scrum and DevOps/CI-CD, the test
  pyramid, and the taxonomy of testing types (functional, regression,
  smoke, sanity, exploratory, performance, security, UAT...). Use when
  planning the QA approach for a project or sprint, explaining testing
  concepts to stakeholders, deciding which test types/levels a change
  needs, defining a test strategy, or onboarding someone to how we test.
---

# Testing Methodologies

## STLC — the lifecycle we follow per feature/release

1. **Requirement analysis** → apply `qa-requirement-review`; output:
   testability verdict + open questions
2. **Test planning** → scope, risks (via `analytical-thinking`),
   approach, estimates; output: test plan
3. **Test design** → apply `test-case-generation`; output: traceable
   test cases + automation candidates
4. **Environment & data setup** → apply `data-faker`; entry criteria
   checked
5. **Execution** → run, log defects via `bug-triage`, retest fixes
6. **Closure** → exit criteria vs actuals, coverage & residual-risk
   report, lessons back into these skills

## QA in Agile (how we embed in Scrum)

- **Refinement**: QA reviews stories for testability BEFORE sprint
  commitment; untestable ACs block "ready".
- **Sprint**: testing is not a phase at the end — test design starts at
  sprint start; automation is part of the story's definition of done,
  not a later backlog item.
- **Whole-team quality**: developers own unit tests; QA owns test
  strategy, exploratory depth, and the automated regression safety net.
- **Per-sprint outputs**: executed test evidence per story, updated
  regression suite, defect trend for the retro.

## QA in DevOps / CI-CD

Pipeline stages and what runs where (shift-left, fast feedback first):

| Stage | Tests | Max duration | Gate |
|---|---|---|---|
| Pre-merge (PR) | unit, lint, component, contract | ~10 min | blocks merge |
| Post-merge | API/integration, smoke E2E | ~30 min | blocks deploy to staging |
| Staging | full regression (automated), targeted manual/exploratory, perf smoke | hours | blocks release |
| Production | smoke on deploy, synthetic monitoring, feature-flag canary | continuous | triggers rollback |

Principles: every gate automated where possible; flaky tests fixed or
quarantined (see `test-automation-standards`); testing in production is
legitimate (canaries, flags, monitoring) — plan it, don't fear it.

## The test pyramid (our default shape)

Unit (many, ms-fast) → API/integration (moderate) → E2E UI (few,
critical journeys only). Justify every E2E test; if an API test can
catch it, write the API test. Inverting the pyramid = slow, flaky
feedback.

## Testing types taxonomy — pick per change

**By purpose**
- *Smoke*: is the build alive? Minutes, runs on every deploy.
- *Sanity*: does the specific fix/area work? Narrow, pre-regression.
- *Functional*: does the feature meet its ACs?
- *Regression*: did we break what already worked? Scope by blast radius
  (see `qa-requirement-review` PR checklist).
- *Exploratory*: time-boxed, charter-driven investigation ("Explore
  <area> with <resources> to discover <risks>"); complements scripted
  tests, mandatory for novel features.
- *UAT*: business validates fitness for purpose; QA facilitates.

**By attribute** — delegate to the specialist skills:
performance → `performance-testing`; security → `security-testing`;
accessibility → `accessibility-testing`; API → `api-testing`;
mobile-specific → `mobile-testing`.

**By knowledge**: black-box (spec-based), white-box (structure-based,
coverage-guided), grey-box (spec + logs/DB access — our default at
system level).

## Choosing scope for a change — quick decision guide

1. What type of change? (new feature / fix / refactor / config / dependency bump)
2. Blast radius? (shared code, contracts, data migrations)
3. Minimum: smoke + functional on the change + regression on the blast
   radius. Add attribute testing when the change touches load paths,
   auth/input handling, UI, or mobile.
