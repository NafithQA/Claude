---
name: visual-regression-testing
description: >
  NEWLY AUTHORED for this kit (no original source recovered) — written
  to match the scope referenced by /qa-visual. Screenshot-based visual
  regression testing: what states to capture, how to keep snapshots
  deterministic, and how to review diffs. Use whenever setting up visual
  regression, reviewing a snapshot diff, or planning a visual QA pass.
---

# Visual Regression Testing

<!-- CUSTOMIZE: your tooling -->
## Stack

- Snapshot tool: [e.g., Playwright's `toHaveScreenshot`, Percy, Chromatic]
- Baseline storage & review flow: [where approved baselines live, who approves diffs]
- CI integration: [stage that runs snapshot tests, how diffs surface in the PR]

## What to snapshot per component/page

Capture each of these that applies, not just the default view:

- Default / empty / loading / error states
- Hover, focus, and active states for key interactive elements
- Light and dark mode, if supported
- RTL layout, if supported
- At least the smallest and largest supported viewport widths

## Determinism setup (do this before trusting any diff)

- Freeze data and time — use `data-faker` fixtures with fixed values
  rather than live/random data
- Disable CSS animations and transitions during capture
- Wait for fonts and images to finish loading before capturing
- Mask or exclude regions that are inherently volatile (timestamps, ads,
  live counters, animated avatars) rather than fighting them into
  determinism

## Baseline review protocol

1. A snapshot diff is not automatically a bug — it's a prompt for human
   review.
2. For each diff: is this an intended visual change (update baseline,
   with the PR that caused it as justification) or an unintended
   regression (file via `bug-triage`)?
3. Never bulk-approve baseline updates without looking at each diff —
   that's how real regressions slip through under cover of a big PR.
4. Record who approved each baseline update and why, for auditability.

## Scaffolding a new snapshot test

If a code environment and the target page/component are available,
generate the test using the project's snapshot tool and the state list
above. Otherwise, output the exact manual test outline (states to view,
viewport sizes, expected visual reference) so it can be executed or
automated later.
