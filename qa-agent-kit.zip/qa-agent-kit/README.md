# QA Agent Kit

A reusable QA agent for Claude Code, plus eighteen org-wide skills that
encode your testing standards, and six slash commands for planned QA
workflows. Drop it into any project — or share it centrally — and every
team gets the same QA behavior.

## What's inside

```
.claude/
├── agents/
│   └── qa-engineer.md              # the agent: role, principles, tool access
├── commands/                       # slash commands that run planned workflows
│   ├── qa-story.md                 # /qa-story  — full workflow for one story
│   ├── qa-sprint.md                # /qa-sprint — full workflow across many stories
│   ├── qa-plan.md                  # /qa-plan   — full test-case generation, filed to Jira
│   ├── qa-release.md               # /qa-release— release readiness / go-no-go
│   ├── qa-bug.md                   # /qa-bug    — triage + files a Jira Bug directly
│   └── qa-visual.md                # /qa-visual — cross-browser/device + visual + Web Vitals
└── skills/
    ├── test-case-generation/       # test case & test plan templates
    ├── test-automation-standards/  # automation code rules & review checklist
    ├── bug-triage/                 # bug report format, severity matrix, triage flow
    ├── qa-requirement-review/      # story testability + QA-lens PR review
    ├── api-testing/                # contract, status-code matrix, resilience
    ├── performance-testing/        # load/stress/soak, targets, reporting (strategy)
    ├── jmeter-load/                # JMeter implementation how-to (companion) ⁑
    ├── security-testing/           # QA-scope security checks + escalation (strategy)
    ├── api-security-testing/       # OWASP API Top 10 test code (companion) ⁑
    ├── accessibility-testing/      # WCAG, keyboard & screen reader checklists *
    ├── data-faker/                 # dummy data + hostile inputs (incl. script) *
    ├── analytical-thinking/        # system decomposition & failure anticipation
    ├── testing-methodologies/      # STLC, Agile/DevOps, test-type taxonomy
    ├── attention-to-detail/        # UI/UX inspection sweeps *
    ├── mobile-testing/             # device matrix, lifecycle, offline, release *
    ├── visual-regression-testing/  # snapshot states, determinism, baseline review ⁑
    ├── frontend-performance/       # Core Web Vitals checks & budgets ⁑
    └── qa-agent-claude/            # autonomous explore→run→heal→report loop, w/ guardrails ⁑
```

Recovery status, so you know what to double-check before relying on it:

- **No mark** — recovered exactly as originally authored.
- **`*`** — original wording wasn't recoverable; rewritten to match its
  known scope. Read before rollout: `accessibility-testing`, `data-faker`,
  `attention-to-detail`, `mobile-testing`.
- **`⁑`** — newly authored from a one-line description only, no original
  content existed to recover. Read carefully, especially
  `api-security-testing` (security test code) and `qa-agent-claude`
  (autonomous-run guardrails), before trusting either in a real
  environment: `jmeter-load`, `api-security-testing`,
  `visual-regression-testing`, `frontend-performance`, `qa-agent-claude`.

The agent is thin; the knowledge lives in the skills. To change how QA
works org-wide, edit a skill once.

## Setup

**Per project:** copy the `.claude/` folder into the repo root and commit
it. Anyone running Claude Code in that repo gets the agent, skills, and
commands.

**Org-wide (recommended):** keep this kit in its own git repo
(e.g., `qa-agent-kit`) as the single source of truth. Projects consume it
by copying (or git submodule / subtree). Personal install is also
possible: `~/.claude/agents/`, `~/.claude/commands/`, and `~/.claude/skills/`.

## Usage

In Claude Code, the agent triggers automatically on QA-related asks, or
invoke it explicitly:

- "Use the qa-engineer agent to write test cases for PROJ-123"
- "qa-engineer: review this PR for quality risks"
- "Triage this bug and draft the Jira ticket"

### Slash commands (planned workflows)

Type these in Claude Code; whatever follows the command becomes its input:

| Command | What it runs |
|---|---|
| `/qa-story PROJ-123` | Full workflow for one story: requirement review → risk → test cases → data → automation plan |
| `/qa-sprint PROJ-101 PROJ-102 …` (or an epic/sprint key) | Runs `/qa-story` across many stories, then a consolidated sprint summary |
| `/qa-plan Checkout v2` | Generates full test-case coverage for a story, lists it for your approval, then files each case as a linked Jira Test Case issue (with a Test Suite issue) in the **Test Cases** project |
| `/qa-release 4.3.0` | Release readiness: regression scope, gates, go/no-go |
| `/qa-bug <description or key>` | Triage + opens a Jira Bug issue directly with the drafted report |
| `/qa-visual <page/route/component>` | Visual QA pass: cross-browser/device matrix + visual regression + Core Web Vitals |

**Confirmation model:** `/qa-story`, `/qa-sprint`, `/qa-release`, and
`/qa-visual` never touch Jira or update baselines without your explicit
confirmation — they draft, you approve. `/qa-bug` files its ticket
directly, no confirmation needed. `/qa-plan` shows you the full case
list and count and waits for your go-ahead before filing anything.

With the Atlassian MCP connected, these commands can read Jira stories
directly by key and write test cases/bugs back to tickets.

## Customize before rollout

Search the skills for `CUSTOMIZE` markers and fill in:

1. Your automation stack (Playwright/Selenium/pytest/etc.), CI names,
   and JMeter environment details
2. Your load-testing tool, security escalation contact, accessibility
   conformance target, and visual regression tool
3. Your ticket ID conventions, Jira workflow states, and — for `/qa-plan`
   and `/qa-bug` — confirm the exact Jira project key behind the
   "Test Cases" project, and that the issue types ("Test Suite", "Test
   Case", "Bug") and link types ("Test Suite", "Test case") in this kit
   match what's configured in your Jira instance

Also give the skills marked `*` and `⁑` above a proper review pass —
they were reconstructed or freshly authored from descriptions rather
than recovered verbatim, so treat them as a first draft.

## Building knowledge over time

Treat the skills as living documents, owned like code:

- **After every retro/escaped defect:** add the lesson to the relevant
  skill (a new checklist item, a new anti-pattern).
- **PR review the changes:** skill edits go through review like any code.
- **Version it:** tag releases of the kit; projects upgrade deliberately.
- **Add project-specific skills** alongside the shared ones (e.g.,
  `payments-domain-testing/`) — shared kit for the "how", local skills
  for the "what".

## Reusing outside Claude Code

The same markdown works as knowledge files in a **Claude.ai Project**
("QA Assistant") for analysts/POs who don't use the terminal: paste the
agent file into the project instructions and upload the skills as
project knowledge.
